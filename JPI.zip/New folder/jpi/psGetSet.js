﻿/*******************************
    MULTIPANEL SWITCH BOARD
*******************************/
// FILES NEEDED FOR psLoad/psRemove
//----------------------------------
//JQuery Library

function psGetSet($$) {
    switch ($$.attr('class').split(' ')[0]) 
    {
     /*
        case 'draw':
            var list = ['draw'];
            
            var qdScript = "<script src='../Apps/draw/quickDraw/JScript.js'></script>";
            chkScript('#loadScript', qdScript);
            $$.html(startQuickDraw('../Apps/draw/quickDraw/'));

            break;
      */
    }//end switch
} //end psGetSet()








